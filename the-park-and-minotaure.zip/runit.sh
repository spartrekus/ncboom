
   echo runit with linux
   prboom -iwad doom2.wad -file  doom2-nat.wad  em1.wad 


